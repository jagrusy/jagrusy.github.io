/*
 * Copyright (c) 2015-2016, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== empty_min.c ========
 */
/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>

/* TI-RTOS Header files */
#include <ti/drivers/I2C.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/SPI.h>

/* My files */
#include "LIS3DH.h"
//#include "SD_Commands.h"

/* Board Header files */
#include "Board.h"

#define TASKSTACKSIZE   1024

// Task are like threads in the TI-RTOS
Task_Struct task0Struct;
Char task0Stack[TASKSTACKSIZE];
/* Pin driver handle */
/*static PIN_Handle PinHandle;
static PIN_State PinState;

PIN_Config CsPinTable[] = {
                           IOID_22 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                           PIN_TERMINATE
                       }; */


/* SPI driver Handle & global Variables*/
/* struct SpiSD{
    SPI_Handle spi;
    SPI_Transaction spiTransaction;
    UChar SPItransmitBuffer[10];
    UChar SPIreceiveBuffer[10];
    Bool transferOK;
    SPI_Params spiParams;
} SD; */
//SPI_Params spiParams;

/* I2C driver Handle  & global Variables */
I2C_Handle      i2c;
I2C_Transaction i2cTransaction;
Bool I2CtransferOK;
uint8_t        writeBuffer[10];
uint8_t        readBuffer[10];
struct accelAxis {
  int8_t x;
  int8_t y;
  int8_t z;
 /* When using LIS3DH in high power mode use declarations below for x, y, and z data */
  /* int16_t x;
   * int16_t y;
   * int16_t z;
   */
};
struct accelAxis LIS3DH_Data;



/* Read Register Function
 * Takes in register number, I2C_transaction structure, readBuffer and writeBuffer
 */
int8_t readRegister(int reg){

            /* Points to register to be read. */
            writeBuffer[0] = reg;
            i2cTransaction.slaveAddress = LIS3DH_SLAVE_ADDR; //slave address of I2C device to talk to
            i2cTransaction.writeBuf = writeBuffer;     //write buffer
            i2cTransaction.writeCount = 1;     //number of bytes to write
            i2cTransaction.readBuf = readBuffer;   //read buffer
            i2cTransaction.readCount = 1;  //number of bytes to read

            I2CtransferOK = I2C_transfer(i2c, &i2cTransaction);
            if(I2CtransferOK)
                {
                    //System_printf("I2C Bus read\n");
                    //System_printf("Data read from register %d \n", readBuffer[0]);
                }
            else
                {
                    System_printf("I2C Bus fault\n");
                    I2C_close(i2c);
                    System_printf("I2C closed!\n");
                    System_flush();
                }

            return (readBuffer[0]);
}
/* Write Register Function
 * Takes in register number, value to be written, I2C_transaction structure, readBuffer and writeBuffer
 */
void writeRegister(int reg, int value){
    /* Points to register to be read. */
            writeBuffer[0] = reg; // register to be written to
            writeBuffer[1] = value; // vaule to to be written to register
            i2cTransaction.slaveAddress = LIS3DH_SLAVE_ADDR; //slave address of I2C device to talk to
            i2cTransaction.writeBuf = writeBuffer;     //write buffer
            i2cTransaction.writeCount = 2;     //number of bytes to write
            i2cTransaction.readBuf = NULL;   //read buffer
            i2cTransaction.readCount = 0;  //number of bytes to read

            I2CtransferOK = I2C_transfer(i2c, &i2cTransaction);
            if(I2CtransferOK)
            {
            System_printf("I2C Bus Written\n");
            //System_printf("Was written to register %d %d \n", writeBuffer[0], writeBuffer[1]);
            System_flush();
            }
            else
            {
            System_printf("I2C Bus fault\n");
            I2C_close(i2c);
            System_printf("I2C closed!\n");
            System_flush();
            }

}
/* Set Data rate, this will effect power consumption of accelerometer */
void setDataRate(lis3dh_dataRate_t dataRate){
    uint8_t ctl1 = readRegister(LIS3DH_REG_CTRL1);
    ctl1 &= ~(0xF0); // mask off bits
    ctl1 |= (dataRate << 4);
    writeRegister(LIS3DH_REG_CTRL1, ctl1);
}
/* Accelerometer Setup */
void beginAccel()
{
           // checking deviceID
           uint8_t deviceID = readRegister(LIS3DH_REG_WHOAMI);
           if (deviceID == 0x33)
           {
               System_printf("Successful Connection to Accelerometer\n");
               System_flush();
           }
           // enabling all axis, low power mode 8 bit on CTRL_REG1
           writeRegister(LIS3DH_REG_CTRL1, 0x0F);
           // enable low power mode 8 bit on CTRL_REG4
           writeRegister(LIS3DH_REG_CTRL4, 0x00); // +/-2g mode
           //writeRegister(LIS3DH_REG_CTRL4, 0x10);  // +/-4g mode
           // Set data rate to 10Hz
           setDataRate(LIS3DH_DATARATE_10_HZ); // Set data rate to 10 Hz
}
void readAxisLow(){
            LIS3DH_Data.x = readRegister(LIS3DH_REG_OUT_X_H);
            LIS3DH_Data.y = readRegister(LIS3DH_REG_OUT_Y_H);
            LIS3DH_Data.z = readRegister(LIS3DH_REG_OUT_Z_H);
            System_printf("Axis data: x = %d, y = %d, z = %d\n", LIS3DH_Data.x, LIS3DH_Data.y, LIS3DH_Data.z);
            System_flush();

}
/* Used when LIS3DH is in High Res Mode */
void readAxisHigh(){
                writeBuffer[0] = LIS3DH_REG_OUT_X_L |0x80; // MSB set to one for autoincrement for multiple reads
                i2cTransaction.slaveAddress = LIS3DH_SLAVE_ADDR; //slave address of I2C device to talk to
                i2cTransaction.writeBuf = writeBuffer;     //write buffer
                i2cTransaction.writeCount = 1;     //number of bytes to write
                i2cTransaction.readBuf = readBuffer;   //read buffer
                i2cTransaction.readCount = 6;  //number of bytes to read

                I2CtransferOK = I2C_transfer(i2c, &i2cTransaction);
                if(I2CtransferOK)
                    {
                        //System_printf("I2C Bus read\n");
                        //System_printf("Data read from register %d \n", readBuffer[0]);
                    }
                else
                    {
                        System_printf("I2C Bus fault\n");
                        I2C_close(i2c);
                        System_printf("I2C closed!\n");
                        System_flush();
                    }
                LIS3DH_Data.x = readBuffer[0] | readBuffer[1]<<8;
                LIS3DH_Data.y = readBuffer[2] | readBuffer[3]<<8;
                LIS3DH_Data.z = readBuffer[4] | readBuffer[5]<<8;

                System_printf("Axis data: x = %d, y = %d, z = %d\n", LIS3DH_Data.x, LIS3DH_Data.y, LIS3DH_Data.z);
                System_flush();

}
// Task for accelerometer 
Void accelCheck(UArg arg0, UArg arg1){


        I2C_Params      i2cParams;


        /* Create I2C for usage */
        I2C_Params_init(&i2cParams);
        i2cParams.transferMode = I2C_MODE_BLOCKING;
        i2cParams.transferCallbackFxn = NULL;
        i2cParams.bitRate = I2C_400kHz;
        i2c = I2C_open(Board_I2C, &i2cParams);
        if (i2c == NULL) {
            System_abort("Error Initializing I2C\n");
        }
        else {
            System_printf("I2C Initialized!\n");
            System_flush();
        }


        // Accelerometer Setup
        beginAccel();

        while(1){

            readAxisLow();
            if(!I2CtransferOK){
                i2c = I2C_open(Board_I2C, &i2cParams);
                        if (i2c == NULL) {
                            System_abort("Error Initializing I2C\n");
                        }
                        else {
                            System_printf("I2C Initialized!\n");
                            System_flush();
                        }
            }
            Task_sleep(1000000 / Clock_tickPeriod);  ///clock tick is 1000us
        }
}

/* SD functions */
/*void goIdle(){
    SD.SPItransmitBuffer[0] = 0b01000000;
    SD.SPItransmitBuffer[1] = 0b00000000;
    SD.SPItransmitBuffer[2] = 0b00000000;
    SD.SPItransmitBuffer[3] = 0b00000000;
    SD.SPItransmitBuffer[4] = 0b00000000;
    SD.SPItransmitBuffer[5] = 0b10010101;

    SD.spiTransaction.count = 6; //number or frames for transaction
    SD.spiTransaction.txBuf = SD.SPItransmitBuffer;
    SD.spiTransaction.rxBuf = SD.SPIreceiveBuffer;

    int i = 0;
    PIN_setOutputValue(PinHandle, IOID_22, 1);
    PIN_setOutputValue(PinHandle, Board_SPI0_MOSI , 1);
    while (i <10000){
               i++;
        }


    SD.transferOK = SPI_transfer(SD.spi, &SD.spiTransaction);
            if (!SD.transferOK) {
                System_printf("Error transfer did not occur\n");
                System_flush();

            }
            System_printf("Response from SD Card was %d\n", SD.SPIreceiveBuffer[5]);
                    System_flush();


}

void readResponse(){
    SD.spiTransaction.count = 1; //number or frames for transaction
    SD.spiTransaction.txBuf = NULL;
    SD.spiTransaction.rxBuf = SD.SPIreceiveBuffer;

    SD.transferOK = SPI_transfer(SD.spi, &SD.spiTransaction);
                if (!SD.transferOK) {
                    System_printf("Error transfer did not occur\n");
                    System_flush();

                }
    System_printf("Response from SD Card was %d\n", SD.SPIreceiveBuffer[0]);
    System_flush();
}


Void spiCheck(UArg arg0, UArg arg1){
        SPI_Params_init(&SD.spiParams);
        SD.spiParams.bitRate = 400; // 400Hz bitrate
        SD.spiParams.dataSize = 8; // 48 bit frames for SD card commands
        SD.spiParams.transferMode = SPI_MODE_BLOCKING;
        SD.spiParams.transferCallbackFxn = NULL;
        SD.spiParams.frameFormat = SPI_POL0_PHA0;
        //SD.spiParams.frameFormat = SPI_POL1_PHA1;
        SD.spi = SPI_open(Board_SPI0, &SD.spiParams);
        if (SD.spi == NULL) {
           System_printf("Error opening spi\n");
           System_flush();

        }
        else {
            System_printf("SPI Initialized!\n");
            System_flush();
        }

        goIdle();
        //readResponse();


        //Task_sleep(1000000 / Clock_tickPeriod);

} */





/*
 *  ======== main ========
 */
int main(void)
{
    Task_Params taskParams;

    /* Call board init functions */
    Board_initGeneral();
    Board_initI2C();
    //Board_initSPI();





    /* Construct Accelerometer Task  thread */
    Task_Params_init(&taskParams);
    taskParams.stackSize = TASKSTACKSIZE;
    taskParams.stack = &task0Stack;
    Task_construct(&task0Struct, (Task_FuncPtr)accelCheck, &taskParams, NULL);
    //Task_construct(&task0Struct, (Task_FuncPtr)spiCheck, &taskParams, NULL);

    /* Open CS pin */
    /*PinHandle = PIN_open(&PinState, CsPinTable);
       if(!PinHandle) {
           System_abort("Error initializing board LED pins\n");
       }*/

    /*System_printf("Starting the I2C example\nSystem provider is set to SysMin."
                  " Halt the target to view any SysMin contents in ROV.\n"); */
    System_printf("PLM Begin.\n");
    /* SysMin will only print to the console when you call flush or exit */
    System_flush();

    /* Start BIOS */
    BIOS_start();

    return (0);
}
